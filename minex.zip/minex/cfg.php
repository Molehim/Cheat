<?php

$email = "xxxxxx";
$password = "xxxxxxx";
$cfduid = "xxxxxx";
