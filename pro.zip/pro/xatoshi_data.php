<?php
# config by : muh maulana
# channel : xatoshi lanzz
# telegram : @cxatoshi

$user_agent = "xxxxx";
$cookie = "xxxxxx";
?>
